/**
 * NOTICES
 * 1. Boleh menambah tapi tidak boleh mengurangi kode template ini.
 * 2. Dilarang mengubah function, event listener, dan DOM yang di-listen
 */

$(document).ready(function(){
    $('.pendidikan').on('click', 'small', function(event){
        //tambahkan kode disini
    });
    $('.kontak').on('click', 'small', function(event){
        //tambahkan kode disini
    });
    $('.pengalaman').on('click', 'small', function(event){
        //tambahkan kode disini
    });
    $('.item-pengalaman').on('click', 'a', function(event){
        //tambahkan kode disini
    })


    //sesuaikan selector dengan class yang ditentukan pada index.html
    $('.facebook').on('mouseenter', logoEnter);
    $('.facebook').on('mouseleave', logoLeave);
    $('.twitter').on('mouseenter', logoEnter);
    $('.twitter').on('mouseleave', logoLeave);
    $('.github').on('mouseenter', logoEnter);
    $('.github').on('mouseleave', logoLeave);
    $('.linkedin').on('mouseenter', logoEnter);
    $('.linkedin').on('mouseleave', logoLeave);

    function logoEnter(){
        //tambahkan kodemu disini
    }
    function logoLeave(){
        //tambahkan kodemu disini
    }
});